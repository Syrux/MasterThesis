#!/usr/bin/env python

###transform transaction to item sid's
### ex:  ./origin_to_sdb.py test/test.dat
#import
import sys
import numpy as np

#read file
f = open(sys.argv[1], 'r')
out = open(sys.argv[1]+".spam64",'w')

c = 1
for e in f.readlines():
	temp = e.strip().split(' ')
	eid = 1
	if len(temp) < 64 :
		for k in temp : 
			out.write(str(c)+' '+str(eid)+" "+k+'\n')
			eid += 1
		c += 1

#close file
f.close()
out.close()

