#!/usr/bin/env python

###transform transaction to item sid's
### ex:  ./origin_to_sdb.py test/test.dat
#import
import sys
import numpy as np

#read file
f = open(sys.argv[1], 'r')
out = open(sys.argv[1]+".sdb",'w')
correspondance = open(sys.argv[1]+".sdb.cor",'w')
correspond_items = open(sys.argv[1]+".sdb.items",'w')


lol = []
for e in f.readlines():
	lol.append(e.strip().split(' '))

lol = np.array(lol)

items = np.unique(np.concatenate(lol, axis=0)) #lol.ravel() ##flatten

items_correspondance = dict()
i = 1
for e in items:
	items_correspondance[e] = i
	correspondance.write("{} = {}\n".format(i,e)) 
	i = i + 1
	

#print  items
#print items_correspondance
correspond_items.write(str({v: k for k, v in items_correspondance.items()}))
correspond_items.write("\n")
correspond_items.write(str(items_correspondance))
correspond_items.write("\n")
correspond_items.write(str(items))
	
#transform
result = []
for e in lol:
	debut = True
	sub_result = []
	for h in e:
		if debut : 
			out.write("%d"%items_correspondance[h])
			debut = False
		else:
			out.write(" %d"%items_correspondance[h])
		sub_result.append(items_correspondance[h])
	result.append(sub_result)
	out.write("\n")

#print result

#put in file

#close file
f.close()
out.close()
correspondance.close()
correspond_items.close()
