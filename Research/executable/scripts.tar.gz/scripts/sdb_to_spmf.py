#!/usr/bin/env python

###transform transaction to item sid's
### ex:  ./origin_to_sdb.py test/test.dat
#import
import sys
import numpy as np

#read file
f = open(sys.argv[1], 'r')
out = open(sys.argv[1]+".spmf",'w')

for e in f.readlines():
	vals = e.strip().split(' ')
	debut = True
	for h in vals:
		if debut : 
			out.write(str(h)+" -1")
			debut = False
		else:
			out.write(" "+str(h)+" -1")
	out.write(" -2\n")


#close file
f.close()
out.close()
